/**
 * map.js - 카카오맵 초기화 및 마커 관리
 */
const MapManager = (() => {
  let map = null;
  let myMarker = null;
  let markers = [];
  let overlays = []; // 커스텀 오버레이 (말풍선)
  let openOverlay = null;

  // ── 지도 초기화 ─────────────────────────────────────────
  function init() {
    const container = document.getElementById('map');
    const options = {
      center: new kakao.maps.LatLng(CONFIG.DEFAULT_CENTER.lat, CONFIG.DEFAULT_CENTER.lng),
      level: CONFIG.DEFAULT_ZOOM,
    };
    map = new kakao.maps.Map(container, options);

    // 지도 클릭 시 열린 오버레이 닫기
    kakao.maps.event.addListener(map, 'click', () => closeOverlay());

    return map;
  }

  // ── 내 위치 마커 ────────────────────────────────────────
  function setMyLocation(lat, lng) {
    const pos = new kakao.maps.LatLng(lat, lng);

    if (myMarker) myMarker.setMap(null);

    // 파란 원형 커스텀 오버레이
    const content = `
      <div style="
        width:18px; height:18px;
        background:#4285f4;
        border:3px solid #fff;
        border-radius:50%;
        box-shadow:0 0 0 5px rgba(66,133,244,0.2);
      "></div>`;

    myMarker = new kakao.maps.CustomOverlay({
      position: pos,
      content,
      zIndex: 10,
    });
    myMarker.setMap(map);
    map.setCenter(pos);
    map.setLevel(4);
  }

  // ── 커스텀 핀 마커 ──────────────────────────────────────
  function addStoreMarker(store, brand, onClickCb) {
    const pos = new kakao.maps.LatLng(store.lat, store.lng);

    // 핀 마커 HTML
    const markerContent = `
      <div class="custom-pin" style="
        display:flex; flex-direction:column; align-items:center;
        cursor:pointer; transform:translate(-50%, -100%);
      ">
        <div style="
          width:30px; height:30px;
          background:${brand.color};
          border-radius:50% 50% 50% 0;
          transform:rotate(-45deg);
          display:flex; align-items:center; justify-content:center;
          font-size:10px; font-weight:700; color:#fff;
          box-shadow:0 2px 6px rgba(0,0,0,0.3);
          font-family:'Noto Sans KR',sans-serif;
          border:2px solid rgba(255,255,255,0.4);
        ">
          <span style="transform:rotate(45deg)">${brand.pin}</span>
        </div>
        <div style="width:2px;height:5px;background:${brand.color};opacity:0.7;"></div>
        <div style="
          background:#fff; border:0.5px solid #ddd;
          border-radius:4px; padding:2px 5px;
          font-size:9px; font-family:'Noto Sans KR',sans-serif;
          white-space:nowrap; max-width:80px;
          overflow:hidden; text-overflow:ellipsis;
          box-shadow:0 1px 3px rgba(0,0,0,0.12);
        ">${store.name.replace(brand.query,'').trim() || store.name}</div>
      </div>`;

    const marker = new kakao.maps.CustomOverlay({
      position: pos,
      content: markerContent,
      zIndex: 5,
    });
    marker.setMap(map);

    // 말풍선 오버레이
    const bubbleContent = `
      <div style="
        background:#fff; border-radius:10px;
        padding:10px 14px; min-width:150px;
        box-shadow:0 3px 14px rgba(0,0,0,0.2);
        font-family:'Noto Sans KR',sans-serif;
        position:relative; bottom:8px;
        border:0.5px solid #eee;
      ">
        <div style="font-size:10px;font-weight:700;color:${brand.color};margin-bottom:3px;">${brand.label}</div>
        <div style="font-size:12px;font-weight:500;color:#1a1a1a;margin-bottom:4px;">${store.name}</div>
        <div style="font-size:10px;color:#888;">${store.address}</div>
        <div style="font-size:11px;font-weight:600;color:${brand.color};margin-top:5px;">📍 ${fmtDist(store.distance)}</div>
      </div>`;

    const overlay = new kakao.maps.CustomOverlay({
      position: pos,
      content: bubbleContent,
      yAnchor: 1.6,
      zIndex: 20,
    });

    // 마커 클릭 이벤트
    const el = document.querySelector('.custom-pin');
    marker.getContent().addEventListener
      ? null : null;

    // DOM 이벤트로 연결
    setTimeout(() => {
      const pinEl = marker.getContent();
      if (typeof pinEl === 'string') return;
      pinEl.addEventListener('click', (e) => {
        e.stopPropagation();
        closeOverlay();
        overlay.setMap(map);
        openOverlay = overlay;
        if (onClickCb) onClickCb(store, brand);
      });
    }, 100);

    markers.push(marker);
    overlays.push(overlay);
    return marker;
  }

  // ── 오버레이 닫기 ────────────────────────────────────────
  function closeOverlay() {
    if (openOverlay) {
      openOverlay.setMap(null);
      openOverlay = null;
    }
  }

  // ── 전체 마커 제거 ──────────────────────────────────────
  function clearMarkers() {
    markers.forEach(m => m.setMap(null));
    overlays.forEach(o => o.setMap(null));
    markers = [];
    overlays = [];
    openOverlay = null;
  }

  // ── 마커 전체 보이도록 범위 조정 ────────────────────────
  function fitBounds(stores) {
    if (stores.length === 0) return;
    const bounds = new kakao.maps.LatLngBounds();
    stores.forEach(s => bounds.extend(new kakao.maps.LatLng(s.lat, s.lng)));
    map.setBounds(bounds, 60, 30, 80, 30);
  }

  // ── 특정 위치로 이동 ────────────────────────────────────
  function panTo(lat, lng) {
    map.setCenter(new kakao.maps.LatLng(lat, lng));
    map.setLevel(3);
  }

  // ── 거리 포맷 ───────────────────────────────────────────
  function fmtDist(m) {
    return m < 1000 ? `${Math.round(m)}m` : `${(m / 1000).toFixed(1)}km`;
  }

  function getMap() { return map; }

  return { init, setMyLocation, addStoreMarker, clearMarkers, fitBounds, panTo, getMap, closeOverlay };
})();
