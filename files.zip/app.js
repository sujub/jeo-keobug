/**
 * app.js - 저커버그 메인 컨트롤러 (카카오 버전)
 */
const App = (() => {

  // ── GPS 위치 가져오기 ────────────────────────────────────
  function getLocation() {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('이 브라우저는 위치 기능을 지원하지 않아요.'));
        return;
      }
      navigator.geolocation.getCurrentPosition(
        p => resolve({ lat: p.coords.latitude, lng: p.coords.longitude }),
        err => {
          const msg = {
            1: '위치 권한이 거부됐어요. 브라우저 설정에서 허용해 주세요.',
            2: '현재 위치를 가져올 수 없어요.',
            3: '위치 요청 시간이 초과됐어요.',
          };
          reject(new Error(msg[err.code] || '위치 오류'));
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
      );
    });
  }

  // ── 카카오 좌표 → 주소 변환 ────────────────────────────
  function getAddress(lat, lng) {
    return new Promise(resolve => {
      const geocoder = new kakao.maps.services.Geocoder();
      geocoder.coord2RegionCode(lng, lat, (result, status) => {
        if (status !== kakao.maps.services.Status.OK) { resolve('현재 위치'); return; }
        // 법정동 이름 (두 번째 결과가 더 정확할 때 있음)
        const region = result.find(r => r.region_type === 'H') || result[0];
        const label = [region.region_2depth_name, region.region_3depth_name]
          .filter(Boolean).join(' ');
        resolve(label || '현재 위치');
      });
    });
  }

  // ── 지도에 마커 렌더링 ──────────────────────────────────
  function renderMarkers(stores) {
    MapManager.clearMarkers();
    stores.forEach(store => {
      const brand = SearchManager.getBrand(store.brandKey);
      if (!brand) return;
      MapManager.addStoreMarker(store, brand, (s) => {
        UIManager.openSheet(s);
      });
    });
    if (stores.length > 0) MapManager.fitBounds(stores);
  }

  // ── 검색 실행 ───────────────────────────────────────────
  async function runSearch(lat, lng) {
    UIManager.setLoading(true);
    try {
      const stores = await SearchManager.searchAllBrands(lat, lng);
      renderMarkers(stores);
      UIManager.renderStoreList(stores, store => {
        MapManager.panTo(store.lat, store.lng);
        UIManager.openSheet(store);
      });
    } catch (err) {
      console.error('[저커버그]', err);
      UIManager.showToast('검색 중 오류가 발생했어요.', 'error');
    } finally {
      UIManager.setLoading(false);
    }
  }

  // ── 이벤트 바인딩 ───────────────────────────────────────
  function bindEvents() {

    // 내 위치 버튼
    document.getElementById('myLocBtn').addEventListener('click', async () => {
      try {
        UIManager.setLoading(true);
        const { lat, lng } = await getLocation();
        MapManager.setMyLocation(lat, lng);
        const addr = await getAddress(lat, lng);
        UIManager.setLocLabel(addr);
        await runSearch(lat, lng);
      } catch (err) {
        UIManager.showToast(err.message, 'error');
        UIManager.setLoading(false);
      }
    });

    // 브랜드 필터 칩
    document.querySelectorAll('.chip').forEach(chip => {
      chip.addEventListener('click', async () => {
        document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        const stores = SearchManager.setFilter(chip.dataset.brand);
        renderMarkers(stores);
        UIManager.renderStoreList(stores, store => {
          MapManager.panTo(store.lat, store.lng);
          UIManager.openSheet(store);
        });
      });
    });

    // 정렬 버튼
    document.querySelectorAll('.sort').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.sort').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const stores = SearchManager.setSort(btn.dataset.sort);
        UIManager.renderStoreList(stores, store => {
          MapManager.panTo(store.lat, store.lng);
          UIManager.openSheet(store);
        });
      });
    });

    // 반경 토글
    const opts = CONFIG.RADIUS_OPTIONS;
    let ridx = opts.indexOf(CONFIG.DEFAULT_RADIUS);
    document.getElementById('radiusBtn').addEventListener('click', async () => {
      ridx = (ridx + 1) % opts.length;
      CONFIG.DEFAULT_RADIUS = opts[ridx];
      document.getElementById('radiusLabel').textContent =
        opts[ridx] >= 1000 ? `${opts[ridx]/1000}km` : `${opts[ridx]}m`;
      SearchManager.setRadius(opts[ridx]);
      const loc = SearchManager.getCurrentLocation();
      if (loc.lat) await runSearch(loc.lat, loc.lng);
    });

    // 검색창 입력
    let timer;
    document.getElementById('searchInput').addEventListener('input', e => {
      clearTimeout(timer);
      const q = e.target.value.trim();
      if (q.length < 2) return;
      timer = setTimeout(async () => {
        UIManager.setLoading(true);
        const stores = await SearchManager.searchByText(q);
        renderMarkers(stores);
        UIManager.renderStoreList(stores, store => {
          MapManager.panTo(store.lat, store.lng);
          UIManager.openSheet(store);
        });
        UIManager.setLoading(false);
      }, 600);
    });

    // 바텀시트 닫기
    document.getElementById('backdrop').addEventListener('click', UIManager.closeSheet);
    document.getElementById('sheetHandle').addEventListener('click', UIManager.closeSheet);

    // 하단 탭
    document.querySelectorAll('.nav').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.nav').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const tab = btn.dataset.tab;
        if (tab === 'fav') UIManager.showToast('즐겨찾기는 곧 추가돼요! 🐛');
        if (tab === 'me')  UIManager.showToast('내 정보는 곧 추가돼요! 🐛');
      });
    });
  }

  // ── 앱 시작 ─────────────────────────────────────────────
  async function init() {
    UIManager.startClock();
    MapManager.init();
    bindEvents();

    try {
      const { lat, lng } = await getLocation();
      MapManager.setMyLocation(lat, lng);
      const addr = await getAddress(lat, lng);
      UIManager.setLocLabel(addr);
      await runSearch(lat, lng);
    } catch (err) {
      UIManager.setLocLabel('위치 권한 필요');
      UIManager.showToast(err.message, 'error');
      UIManager.setLoading(false);
    }
  }

  return { init };
})();

// 카카오맵 SDK 로드 후 실행
window.addEventListener('load', () => App.init());
