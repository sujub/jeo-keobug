/**
 * config.js - 저커버그 설정
 * 카카오 API 키 및 브랜드 정보
 */
const CONFIG = {

  // 카카오 REST API 키 (매장 검색용 - 서버 사이드 불필요, JS에서 직접 호출 가능!)
  KAKAO_REST_API_KEY: '8120a790cd00bf8a69b6f1bce85363e7',

  // 카카오 JavaScript 키 (index.html SDK 로드에 이미 사용됨)
  KAKAO_JS_KEY: '7f1706ef893b6c60d77084a91e9d9521',

  // 검색할 저가 커피 브랜드
  BRANDS: [
    {
      key: '메가MGC커피',
      label: '메가커피',
      query: '메가MGC커피',
      short: '메가',
      color: '#bf360c',
      bg: '#fff3e0',
      pin: 'M',
    },
    {
      key: '컴포즈커피',
      label: '컴포즈',
      query: '컴포즈커피',
      short: '컴포즈',
      color: '#1b5e20',
      bg: '#e8f5e9',
      pin: 'C',
    },
    {
      key: '빽다방',
      label: '빽다방',
      query: '빽다방',
      short: '빽',
      color: '#e65100',
      bg: '#fffde7',
      pin: 'P',
    },
    {
      key: '맘모스커피',
      label: '맘모스',
      query: '맘모스커피',
      short: '맘모스',
      color: '#880e4f',
      bg: '#fce4ec',
      pin: 'M',
    },
  ],

  // 반경 옵션 (미터)
  RADIUS_OPTIONS: [500, 1000, 2000, 3000],
  DEFAULT_RADIUS: 1000,

  // 기본 지도 중심 (서울 시청 - 위치 권한 거부 시 폴백)
  DEFAULT_CENTER: { lat: 37.5665, lng: 126.9780 },
  DEFAULT_ZOOM: 5, // 카카오맵 줌레벨 (1=가장 크게, 14=가장 작게)
};
