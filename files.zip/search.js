/**
 * search.js - 카카오 로컬 API로 주변 저가 커피 매장 검색
 * ✅ 카카오는 위도/경도 + 반경 검색 지원! 프록시 서버 불필요!
 */
const SearchManager = (() => {
  let currentLat = null;
  let currentLng = null;
  let allStores = [];
  let filteredStores = [];
  let activeFilter = 'all';
  let activeSort = 'distance';
  let searchRadius = CONFIG.DEFAULT_RADIUS;

  // ── 두 좌표 간 거리 계산 (Haversine) ────────────────────
  function calcDistance(lat1, lng1, lat2, lng2) {
    const R = 6371000;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLng / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  // ── 단일 브랜드 검색 (카카오 키워드 검색 API) ───────────
  function searchBrand(brand, lat, lng, radius) {
    return new Promise((resolve) => {
      const url = new URL('https://dapi.kakao.com/v2/local/search/keyword.json');
      url.searchParams.set('query', brand.query);
      url.searchParams.set('x', lng);           // 경도
      url.searchParams.set('y', lat);           // 위도
      url.searchParams.set('radius', radius);   // 반경(m) - 카카오는 이게 됩니다!
      url.searchParams.set('size', 15);         // 최대 15개
      url.searchParams.set('sort', 'distance'); // 거리순 정렬

      fetch(url.toString(), {
        headers: {
          'Authorization': `KakaoAK ${CONFIG.KAKAO_REST_API_KEY}`,
        },
      })
        .then(res => {
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          return res.json();
        })
        .then(data => {
          if (!data.documents || data.documents.length === 0) {
            resolve([]);
            return;
          }

          const stores = data.documents.map(item => ({
            id: item.id,
            name: item.place_name,
            address: item.road_address_name || item.address_name,
            phone: item.phone,
            lat: parseFloat(item.y),
            lng: parseFloat(item.x),
            distance: parseFloat(item.distance) || calcDistance(lat, lng, parseFloat(item.y), parseFloat(item.x)),
            brandKey: brand.key,
            kakaoUrl: item.place_url,
          }));

          resolve(stores);
        })
        .catch(err => {
          console.error(`[저커버그] ${brand.label} 검색 실패:`, err.message);
          resolve([]);
        });
    });
  }

  // ── 전체 브랜드 동시 검색 ───────────────────────────────
  async function searchAllBrands(lat, lng) {
    currentLat = lat;
    currentLng = lng;

    const brandsToSearch = activeFilter === 'all'
      ? CONFIG.BRANDS
      : CONFIG.BRANDS.filter(b => b.key === activeFilter);

    // 모든 브랜드 병렬 검색
    const results = await Promise.allSettled(
      brandsToSearch.map(b => searchBrand(b, lat, lng, searchRadius))
    );

    // 중복 제거 후 합치기
    const seen = new Set();
    allStores = results
      .flatMap(r => r.status === 'fulfilled' ? r.value : [])
      .filter(s => {
        if (seen.has(s.id)) return false;
        seen.add(s.id);
        return true;
      });

    applyFilterAndSort();
    return filteredStores;
  }

  // ── 필터 + 정렬 적용 ────────────────────────────────────
  function applyFilterAndSort() {
    filteredStores = activeFilter === 'all'
      ? [...allStores]
      : allStores.filter(s => s.brandKey === activeFilter);

    if (activeSort === 'distance') {
      filteredStores.sort((a, b) => a.distance - b.distance);
    } else {
      filteredStores.sort((a, b) => a.name.localeCompare(b.name));
    }
  }

  // ── 텍스트 검색 ─────────────────────────────────────────
  async function searchByText(query) {
    if (!currentLat) {
      UIManager.showToast('위치 정보가 필요합니다!', 'error');
      return [];
    }
    // 브랜드 매칭
    const matched = CONFIG.BRANDS.find(b =>
      query.includes(b.label) || query.includes(b.key) || query.includes(b.short)
    );
    const brand = matched || {
      key: 'custom', label: '검색결과',
      query, short: '?', color: '#555', bg: '#f5f5f5', pin: '?',
    };

    const stores = await searchBrand(brand, currentLat, currentLng, searchRadius);
    allStores = stores;
    applyFilterAndSort();
    return filteredStores;
  }

  function setFilter(key) { activeFilter = key; applyFilterAndSort(); return filteredStores; }
  function setSort(key)   { activeSort = key;   applyFilterAndSort(); return filteredStores; }
  function setRadius(m)   { searchRadius = m; }
  function getBrand(key)  { return CONFIG.BRANDS.find(b => b.key === key); }
  function getFilteredStores() { return filteredStores; }
  function getCurrentLocation() { return { lat: currentLat, lng: currentLng }; }

  return {
    searchAllBrands, searchByText,
    setFilter, setSort, setRadius,
    getBrand, getFilteredStores, getCurrentLocation,
  };
})();
