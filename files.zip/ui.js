/**
 * ui.js - UI 렌더링 (매장 목록, 바텀시트, 토스트)
 */
const UIManager = (() => {

  function fmtDist(m) {
    return m < 1000 ? `${Math.round(m)}m` : `${(m / 1000).toFixed(1)}km`;
  }

  // ── 매장 목록 렌더링 ────────────────────────────────────
  function renderStoreList(stores, onClickCb) {
    const list   = document.getElementById('storeList');
    const empty  = document.getElementById('emptyState');
    const result = document.getElementById('resultText');
    const badge  = document.getElementById('countBadge');
    const radius = CONFIG.DEFAULT_RADIUS >= 1000
      ? `${CONFIG.DEFAULT_RADIUS / 1000}km` : `${CONFIG.DEFAULT_RADIUS}m`;

    badge.textContent = `매장 ${stores.length}개`;

    if (stores.length === 0) {
      list.innerHTML = '';
      list.appendChild(empty);
      empty.style.display = 'flex';
      empty.querySelector('p').textContent = '주변에 매장이 없어요 😅';
      empty.querySelector('small').textContent = '반경을 늘리거나 다른 브랜드를 선택해 보세요';
      result.textContent = '검색된 매장이 없습니다';
      return;
    }

    empty.style.display = 'none';
    result.innerHTML = `반경 ${radius} · <strong>${stores.length}개</strong> 매장 발견`;

    list.innerHTML = stores.map((store, idx) => {
      const brand = SearchManager.getBrand(store.brandKey)
        || { color: '#555', bg: '#f5f5f5', short: '?', label: store.brandKey };
      return `
        <div class="store-item" data-idx="${idx}" tabindex="0" role="button">
          <div class="store-badge" style="background:${brand.bg};color:${brand.color};">
            ${brand.short}
          </div>
          <div class="store-info">
            <div class="store-name">${store.name}</div>
            <div class="store-addr">${store.address}</div>
            <div class="store-meta">
              <span class="dist" style="color:${brand.color}">📍 ${fmtDist(store.distance)}</span>
              ${store.phone ? `<span class="phone">📞 ${store.phone}</span>` : ''}
            </div>
          </div>
          <span class="arrow">›</span>
        </div>`;
    }).join('');

    list.querySelectorAll('.store-item').forEach(el => {
      const handler = () => onClickCb(stores[parseInt(el.dataset.idx)]);
      el.addEventListener('click', handler);
      el.addEventListener('keydown', e => { if (e.key === 'Enter') handler(); });
    });
  }

  // ── 바텀시트 열기 ────────────────────────────────────────
  function openSheet(store) {
    const brand = SearchManager.getBrand(store.brandKey)
      || { color: '#555', bg: '#f5f5f5', label: store.brandKey };

    document.getElementById('sheetBody').innerHTML = `
      <div class="sheet-header">
        <div class="sheet-badge" style="background:${brand.bg};color:${brand.color};">${brand.label}</div>
        <div>
          <div class="sheet-name">${store.name}</div>
          <div class="sheet-dist" style="color:${brand.color}">📍 ${fmtDist(store.distance)}</div>
        </div>
      </div>
      <div class="sheet-rows">
        <div class="sheet-row"><span>📌</span><span>${store.address}</span></div>
        ${store.phone ? `<div class="sheet-row"><span>📞</span><a href="tel:${store.phone}" style="color:#2D5016;font-weight:500;">${store.phone}</a></div>` : ''}
      </div>
      <div class="sheet-actions">
        <button class="btn-primary" onclick="window.open('https://map.kakao.com/link/to/${encodeURIComponent(store.name)},${store.lat},${store.lng}','_blank')">
          🗺️ 카카오맵으로 길찾기
        </button>
        ${store.kakaoUrl ? `<button class="btn-secondary" onclick="window.open('${store.kakaoUrl}','_blank')">🔍 카카오맵 상세보기</button>` : ''}
        <button class="btn-secondary" onclick="navigator.clipboard.writeText('${store.address}').then(()=>UIManager.showToast('주소 복사됐어요! 📋'))">
          📋 주소 복사
        </button>
      </div>`;

    document.getElementById('sheet').classList.add('open');
    document.getElementById('backdrop').classList.add('show');
  }

  function closeSheet() {
    document.getElementById('sheet').classList.remove('open');
    document.getElementById('backdrop').classList.remove('show');
  }

  function setLoading(on) {
    document.getElementById('mapLoading').style.display = on ? 'flex' : 'none';
    if (on) document.getElementById('resultText').textContent = '매장 탐색 중...';
  }

  function setLocLabel(text) {
    document.getElementById('locText').textContent = text;
  }

  function startClock() {
    const tick = () => {
      const n = new Date();
      const el = document.getElementById('clock');
      if (el) el.textContent =
        `${String(n.getHours()).padStart(2,'0')}:${String(n.getMinutes()).padStart(2,'0')}`;
    };
    tick();
    setInterval(tick, 30000);
  }

  function showToast(msg, type = 'info') {
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.classList.add('show'), 10);
    setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); }, 3000);
  }

  return { renderStoreList, openSheet, closeSheet, setLoading, setLocLabel, startClock, showToast };
})();
